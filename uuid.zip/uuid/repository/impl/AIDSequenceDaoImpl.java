package com.ps.nextgen.uuid.repository.impl;

import com.ps.nextgen.exceptions.ENPLDataNotFoundException;
import com.ps.nextgen.exceptions.ENPLException;
import com.ps.nextgen.uuid.domain.AIDSequence;
import com.ps.nextgen.uuid.repository.AIDSequenceDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import java.util.LinkedHashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.LongStream;

@Repository
public class AIDSequenceDaoImpl implements AIDSequenceDao {

    @Autowired
    private MongoTemplate mongoTemplate;

    private final String sequenceName;

    public AIDSequenceDaoImpl(@Value("${feature.uuid.generate-aid.sequence.name}") String sequenceName) {
        this.sequenceName = sequenceName;
    }

    @Override
    public Set<Long> generateAIDSequence(String projectType, long count) {
        final Query query = new Query();
        query.addCriteria(Criteria.where("_id").is(sequenceName));

        final Update update = new Update();
        //Increment the respective attribute by count i.e. number of AID sequences requested.
        //We do this to avoid multiple DB calls and instead only make one when bulk AIDs are requested.
        update.inc(projectType.toLowerCase(), count);

        final FindAndModifyOptions opts = new FindAndModifyOptions();
        //Return the updated version of the document. This is done so that we can derive the sequences
        // in order based on the current value and the requested count.
        opts.returnNew(true);

        final AIDSequence updatedSeq = mongoTemplate.findAndModify(query, update, opts, AIDSequence.class);
        if (updatedSeq == null) {
            //This will never happen unless we miss creating the initial object
            // in the psdp_efa_aid_sequence collection.
            throw new ENPLDataNotFoundException("Could not find AID sequence object, please connect with EnrichPlus support.");
        }

        final long endSequence = Optional.ofNullable(updatedSeq.getSequence(projectType))
                .orElseThrow(
                        //AIDSequence#getSequence should never return null. This is an unexpected case
                        // and can happen if we have wrong mapping in AIDSequence#getSequence method or
                        // incorrect Query/Update objects were created.
                        () -> new ENPLException("Unexpected error generating sequences, please connect with EnrichPlus support.")
                );

        final long startSequence = endSequence - count;
        if (startSequence <= 0) {
            //This is an unexpected case and can happen if we incorrectly increment the sequence
            // or when ACID is breached for the document.
            throw new ENPLException("Unexpected error generating sequences, please connect with EnrichPlus support.");
        }

        return extractSequences(startSequence, endSequence);
    }

    /**
     * Extract sequence numbers between two bounds.
     *
     * @param startSequence - Inclusive initial sequence
     * @param endSequence   - Exclusive bound sequence
     * @return - Ordered set of sequence numbers between startSequence (inclusive) and endSequence (exclusive)
     */
    private Set<Long> extractSequences(long startSequence, long endSequence) {
        return LongStream.range(startSequence, endSequence)
                .boxed()
                //Make sure we are collecting the result into a LinkedHashSet
                // to maintain the order of sequence numbers.
                .collect(Collectors.toCollection(LinkedHashSet::new));
    }
}
