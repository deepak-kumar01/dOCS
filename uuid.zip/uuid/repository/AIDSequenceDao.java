package com.ps.nextgen.uuid.repository;

import java.util.Set;

public interface AIDSequenceDao {
    Set<Long> generateAIDSequence(String projectType, long count);
}
