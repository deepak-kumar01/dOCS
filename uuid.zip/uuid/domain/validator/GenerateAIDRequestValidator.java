package com.ps.nextgen.uuid.domain.validator;

import com.ps.nextgen.exceptions.ENPLValidationException;
import com.ps.nextgen.uuid.domain.GenerateAIDRequest;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Set;

@Component
@Qualifier("GenerateAIDRequestValidator")
@Getter
@Setter
public class GenerateAIDRequestValidator implements ENPLDataValidator<GenerateAIDRequest> {

    @Value("${feature.uuid.generate-aid.supported-project-types}")
    private Set<String> supportedProjectTypes;

    @Value("${feature.uuid.generate-aid.max-count-per-request:500}")
    private int maxCountPerRequest;

    @Override
    public void validate(GenerateAIDRequest request) throws ENPLValidationException {
        if (request == null) {
            throw new ENPLValidationException("null request");
        }

        if (request.getProjectType() == null || !supportedProjectTypes.contains(request.getProjectType())) {
            throw new ENPLValidationException(
                    String.format(
                            "Unsupported project type: %s. Supported values are: %s",
                            request.getProjectType(),
                            StringUtils.join(supportedProjectTypes, ", ")
                    )
            );
        }

        if (request.getCount() <= 0) {
            throw new ENPLValidationException(
                    String.format(
                            "Requested count of AID(s) cannot be zero or less than zero. [count=%d]",
                            request.getCount()
                    )
            );
        }

        if (request.getCount() > maxCountPerRequest) {
            throw new ENPLValidationException(
                    String.format(
                            "Requested %s against maximum of %d AID(s) which can be generated per request.",
                            request.getCount(),
                            maxCountPerRequest
                    )
            );
        }
    }
}
