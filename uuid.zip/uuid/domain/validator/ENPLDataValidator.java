package com.ps.nextgen.uuid.domain.validator;

import com.ps.nextgen.exceptions.ENPLValidationException;

public interface ENPLDataValidator<T> {
    void validate(T input) throws ENPLValidationException;
}
