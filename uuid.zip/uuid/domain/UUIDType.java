package com.ps.nextgen.uuid.domain;

import com.ps.nextgen.exceptions.ENPLValidationException;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.Optional;

public enum UUIDType {
    AID;

    public static UUIDType parse(String value) {
        return Optional.ofNullable(value)
                .filter(_v -> Arrays.stream(values()).anyMatch(type -> _v.equals(type.name())))
                .map(UUIDType::valueOf)
                .orElseThrow(() -> new ENPLValidationException(
                        String.format(
                                "Unsupported value for 'uuidType': %s. Supported values: %s",
                                value,
                                StringUtils.join(values(), ",")
                        )
                ));
    }
}
