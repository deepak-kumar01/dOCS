package com.ps.nextgen.uuid.domain.mapper;

import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Format into AID pattern.
 * <p>
 * Pattern: E<PRODUCT_TYPE>-<YYMMDD>-<AID_SEQUENCE>
 * <p>
 * where
 * <p>
 * PRODUCT_TYPE - type from request input
 * YYMMDD - System date i.e. LocalDate.now()
 * AID_SEQUENCE - auto incremented sequence provided as input.
 */
@Component
@Qualifier("SequenceToAIDMapper")
public class AIDSequenceToAIDMapper implements ENPLDataMapper<Pair<String, Long>, String> {

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("MMddyy");
    private static final String AID_PATTERN = "E%s-%s-%d";

    @Override
    public String map(Pair<String, Long> input) {
        return String.format(
                AID_PATTERN,
                input.getLeft(), LocalDate.now().format(DATE_FORMATTER), input.getRight()
        );
    }
}
