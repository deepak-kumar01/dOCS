package com.ps.nextgen.uuid.domain.mapper;

import com.ps.nextgen.exceptions.ENPLValidationException;
import com.ps.nextgen.uuid.domain.GenerateAIDRequest;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class GenerateAIDRequestMapper implements ENPLDataMapper<Map<String, String>, GenerateAIDRequest> {

    @Override
    public GenerateAIDRequest map(Map<String, String> params) {
        final int count = parseCount(params.getOrDefault("count", "1"));
        return new GenerateAIDRequest(params.get("projectType"), count);
    }

    private int parseCount(String _value) {
        try {
            return StringUtils.isNotBlank(_value)
                    ? Integer.parseInt(_value)
                    : 0;
        } catch (NumberFormatException e) {
            throw new ENPLValidationException(
                    String.format(
                            "Invalid value for count: %s. Expecting a valid numeric value.",
                            _value
                    )
            );
        }
    }
}
