package com.ps.nextgen.uuid.domain.mapper;

public interface ENPLDataMapper<I, O> {
    O map(I input);
}
