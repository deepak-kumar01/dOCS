package com.ps.nextgen.uuid.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.ToString;
import org.apache.commons.lang3.exception.ExceptionUtils;

import java.util.Optional;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@ToString
public class BaseENPLResponse<T> implements ENPLResponse<T> {

    private final Status status;
    private final String message;
    private final String error;
    private final T data;

    private BaseENPLResponse(Status status, String message, String error, T data) {
        this.status = status;
        this.message = message;
        this.error = error;
        this.data = data;
    }

    public static <T> BaseENPLResponse<T> success(String message, T data) {
        return new BaseENPLResponse<>(Status.SUCCESS, message, null, data);
    }

    public static <T> BaseENPLResponse<T> success(String message) {
        return success(message, null);
    }

    public static <T> BaseENPLResponse<T> fail(String error, T data) {
        return new BaseENPLResponse<>(Status.FAIL, null, error, data);
    }

    public static <T> BaseENPLResponse<T> fail(String error) {
        return new BaseENPLResponse<>(Status.FAIL, null, error, null);
    }

    public static <T> BaseENPLResponse<T> fail(Exception error, T data) {
        return fail(Optional.ofNullable(error).map(ExceptionUtils::getRootCauseMessage).orElse(null), data);
    }

    public static <T> BaseENPLResponse<T> fail(Exception error) {
        return fail(Optional.ofNullable(error).map(ExceptionUtils::getRootCauseMessage).orElse(null));
    }
}
