package com.ps.nextgen.uuid.domain;

public interface ENPLResponse<T> {
    Status getStatus();

    String getMessage();

    String getError();

    T getData();

    enum Status {
        SUCCESS, FAIL
    }
}
