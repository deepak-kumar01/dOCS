package com.ps.nextgen.uuid.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;

import java.util.Set;

@Data
@AllArgsConstructor
@ToString
public class GenerateAIDResponse implements GenerateUUIDResponse<String> {

    private final Set<String> generatedUUID;

    @Override
    public UUIDType getType() {
        return UUIDType.AID;
    }

    @Override
    public Set<String> getGeneratedUUID() {
        return generatedUUID;
    }
}
