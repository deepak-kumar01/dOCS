package com.ps.nextgen.uuid.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;

@Data
@AllArgsConstructor
@ToString
public class GenerateAIDRequest implements GenerateUUIDRequest {

    private final String projectType;
    private final long count;

    @Override
    public UUIDType getType() {
        return UUIDType.AID;
    }
}
