package com.ps.nextgen.uuid.domain;

public interface GenerateUUIDRequest {
    UUIDType getType();
    long getCount();
}
