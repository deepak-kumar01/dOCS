package com.ps.nextgen.uuid.domain;

import java.util.Set;

public interface GenerateUUIDResponse<T> {
    UUIDType getType();
    Set<T> getGeneratedUUID();
}
