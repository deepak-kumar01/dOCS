package com.ps.nextgen.uuid.domain;

import lombok.AllArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Objects;

@Document(collection = "psdp_efa_aid_sequence")
@AllArgsConstructor
public class AIDSequence {

    /**
     * Name of the sequence.
     */
    @Id
    private String id;

    /**
     * AID sequence for C type jobs.
     */
    private Long c;

    /**
     * AID sequence for X type jobs.
     */
    private Long x;

    /**
     * AID sequence for H type jobs.
     */
    private Long h;

    /**
     * AID sequence for B type jobs.
     */
    private Long b;

    /**
     * AID sequence for NI type jobs.
     */
    private Long ni;


    /**
     *
     * @param type - project Type, supported values are c, x, h, b, ni.
     * @return sequence associated with the type.
     */
    public Long getSequence(String type) {
        if (type == null) {
            throw new IllegalArgumentException(
                    "Unable to get AID sequence, null is not a valid value for 'projectType'."
            );
        }

        switch (type.toLowerCase()) {
            case "c":
                return c;
            case "x":
                return x;
            case "h":
                return h;
            case "b":
                return b;
            case "ni":
                return ni;
            default:
                throw new IllegalArgumentException(
                        String.format(
                                "Unable to get AID sequence, %s is not a valid value for 'projectType'.",
                                type
                        )
                );
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AIDSequence that = (AIDSequence) o;
        return Objects.equals(id, that.id) && Objects.equals(c, that.c) && Objects.equals(x, that.x) && Objects.equals(h, that.h) && Objects.equals(b, that.b) && Objects.equals(ni, that.ni);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, c, x, h, b, ni);
    }

    @Override
    public String toString() {
        return "AIDSequence{" +
                "id='" + id + '\'' +
                ", c=" + c +
                ", x=" + x +
                ", h=" + h +
                ", b=" + b +
                ", ni=" + ni +
                '}';
    }
}
