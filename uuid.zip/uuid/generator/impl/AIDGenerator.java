package com.ps.nextgen.uuid.generator.impl;

import com.ps.nextgen.uuid.domain.GenerateAIDRequest;
import com.ps.nextgen.uuid.generator.UUIDGenerator;
import com.ps.nextgen.uuid.service.impl.AIDGenerationService;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.LongStream;

@Component
@Getter
@Setter
@Slf4j
public class AIDGenerator implements UUIDGenerator<GenerateAIDRequest, Set<String>> {

    @Getter(AccessLevel.NONE)
    private final AIDGenerationService aidGenerationService;

    @Value("${feature.uuid.generate-aid.max-count-per-request:500}")
    private int maxCountPerRequest;

    public AIDGenerator(@Autowired AIDGenerationService aidGenerationService) {
        this.aidGenerationService = aidGenerationService;
    }

    @Override
    public Set<String> generate(GenerateAIDRequest request) {
        final long startTimestamp = System.currentTimeMillis();

        log.info("Generating {} AID(s) for project type: {}", request.getCount(), request.getProjectType());

        Set<String> generatedAIDs;
        if (countExceedsMaxCountPerRequest(request.getCount())) {
            log.info(
                    "Requested count of {} exceeds max per-request count of {} for AID generation. Batching request...",
                    request.getCount(),
                    maxCountPerRequest
            );

            final List<Long> countPerRequest = getCountPerRequest(request.getCount());
            final int batchCount = countPerRequest.size();
            log.info("AID generation request broken into {} batches", batchCount);

            generatedAIDs = IntStream.range(0, countPerRequest.size())
                    .mapToObj(index -> {
                        final long count = countPerRequest.get(index);
                        final Set<String> result = aidGenerationService.generateUUID(new GenerateAIDRequest(request.getProjectType(), count)).getGeneratedUUID();
                        log.info("[{}/{}] AID Generated: {}", index, batchCount, count);
                        return result;
                    })
                    .flatMap(Collection::stream)
                    .collect(Collectors.toCollection(LinkedHashSet::new));
        } else {
            generatedAIDs = aidGenerationService.generateUUID(request).getGeneratedUUID();
        }

        log.info(
                "Generated {}/{} AID(s) in {} ms: {}",
                generatedAIDs.size(),
                request.getCount(),
                (System.currentTimeMillis() - startTimestamp),
                StringUtils.join(generatedAIDs, ",")
        );


        return generatedAIDs;
    }

    private boolean countExceedsMaxCountPerRequest(long totalCount) {
        return totalCount > maxCountPerRequest;
    }

    private List<Long> getCountPerRequest(long totalCount) {
        final long totalBatches = totalCount / maxCountPerRequest;
        final long reminder = totalCount % maxCountPerRequest;

        final List<Long> countByRequest = LongStream.range(0, totalBatches)
                .map(i -> maxCountPerRequest)
                .boxed()
                .collect(Collectors.toList());

        if (reminder > 0) {
            countByRequest.add(reminder);
        }

        return countByRequest;
    }
}
