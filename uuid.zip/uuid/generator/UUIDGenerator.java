package com.ps.nextgen.uuid.generator;

public interface UUIDGenerator<I, O> {
    O generate(I input);
}
