package com.ps.nextgen.uuid.service;

import com.ps.nextgen.uuid.domain.GenerateUUIDRequest;
import com.ps.nextgen.uuid.domain.GenerateUUIDResponse;

public interface UUIDGenerationService<Request extends GenerateUUIDRequest, Response extends GenerateUUIDResponse<?>> {
    Response generateUUID(Request request);
}
