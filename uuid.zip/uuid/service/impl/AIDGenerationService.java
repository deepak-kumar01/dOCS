package com.ps.nextgen.uuid.service.impl;

import com.ps.nextgen.exceptions.ENPLException;
import com.ps.nextgen.uuid.domain.GenerateAIDRequest;
import com.ps.nextgen.uuid.domain.GenerateAIDResponse;
import com.ps.nextgen.uuid.domain.mapper.ENPLDataMapper;
import com.ps.nextgen.uuid.domain.validator.ENPLDataValidator;
import com.ps.nextgen.uuid.repository.AIDSequenceDao;
import com.ps.nextgen.uuid.service.UUIDGenerationService;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.LinkedHashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Qualifier("AIDGenerationService")
public class AIDGenerationService implements UUIDGenerationService<GenerateAIDRequest, GenerateAIDResponse> {

    @Autowired
    private AIDSequenceDao aidSequenceDao;

    @Autowired
    @Qualifier("SequenceToAIDMapper")
    private ENPLDataMapper<Pair<String, Long>, String> aidMapper;

    @Autowired
    @Qualifier("GenerateAIDRequestValidator")
    private ENPLDataValidator<GenerateAIDRequest> requestValidator;

    @Override
    public GenerateAIDResponse generateUUID(GenerateAIDRequest request) {
        requestValidator.validate(request);

        final Set<Long> sequences = aidSequenceDao.generateAIDSequence(request.getProjectType(), request.getCount());
        final int generatedCount = Optional.of(sequences).map(Set::size).orElse(0);

        if (generatedCount < request.getCount()) {
            //should never happen
            throw new ENPLException(
                    String.format(
                            "Mismatch in AID sequence generation, requested: %d | generated: %d | delta: %d",
                            request.getCount(),
                            generatedCount,
                            request.getCount() - generatedCount
                    )
            );
        }

        final Set<String> generatedAIDs = sequences.stream()
                .map(seq -> aidMapper.map(Pair.of(request.getProjectType(), seq)))
                .collect(Collectors.toCollection(LinkedHashSet::new));

        return new GenerateAIDResponse(generatedAIDs);
    }
}
