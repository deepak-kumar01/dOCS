package com.ps.nextgen.exceptions;

//@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class DealNotUpdatedException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public DealNotUpdatedException(String message) {
		
		super(message);
	}
}
