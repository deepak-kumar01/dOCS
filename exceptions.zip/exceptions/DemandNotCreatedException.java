package com.ps.nextgen.exceptions;

public class DemandNotCreatedException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

	public DemandNotCreatedException(String message) {
		
		super(message);
	}

}
