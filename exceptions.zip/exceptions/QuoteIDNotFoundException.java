package com.ps.nextgen.exceptions;

public class QuoteIDNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public QuoteIDNotFoundException(String message) {
		super(message);
	}
}
