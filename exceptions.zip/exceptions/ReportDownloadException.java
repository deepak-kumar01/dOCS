package com.ps.nextgen.exceptions;

public class ReportDownloadException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public ReportDownloadException(String message) {
		super(message);

}

}
