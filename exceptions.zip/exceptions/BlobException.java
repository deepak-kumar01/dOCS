package com.ps.nextgen.exceptions;

public class BlobException extends Exception {
    private static final long serialVersionUID = 1L;

    public BlobException(String message) {
        super(message);
    }
}
