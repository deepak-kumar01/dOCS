package com.ps.nextgen.exceptions;

//@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
public class CopyPidException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CopyPidException(String message) {
		super(message);

	}

}

