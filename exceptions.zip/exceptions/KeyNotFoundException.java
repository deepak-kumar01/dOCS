package com.ps.nextgen.exceptions;

import org.springframework.web.bind.annotation.ResponseStatus;

import org.springframework.http.HttpStatus;

@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class KeyNotFoundException extends RuntimeException {

	/**
	 * Exception class for input data.
	 */
	private static final long serialVersionUID = 1L;

	public KeyNotFoundException(String message) {
		super(message);

	}
}
