package com.ps.nextgen.exceptions;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.mongodb.MongoException;
import com.ps.nextgen.exception.UserNotAllowedException;

@ControllerAdvice
@RestController
public class PsResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {
	
	//@ExceptionHandler(MongoException.class)
	public ResponseEntity<Object> handleMongoSideException(Exception ex, HttpServletRequest request,
			HttpServletResponse response) {
		ex.printStackTrace();
		//We can add notification flow here if required.
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(),
				ExceptionMessageConstants.INTERNAL_MONGO_ERROR, ex.getClass().getName());
		return new ResponseEntity<>(exceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(RequestConflictException.class)
	public final ResponseEntity handleRequestConflictException(RequestConflictException ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(),
				ExceptionMessageConstants.RECORD_UNDER_MODIFICATION_ERROR, ex.getMessage());

		return new ResponseEntity<>(exceptionResponse, HttpStatus.CONFLICT);
	}

	@ExceptionHandler(DealNotFoundException.class)
	public final ResponseEntity handleRequestConflictException(DealNotFoundException ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(),
				ExceptionMessageConstants.DEAL_NOT_FOUND_ERROR, ex.getMessage());

		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(DealNotUpdatedException.class)
	public final ResponseEntity handleRequestConflictException(DealNotUpdatedException ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(),
				ExceptionMessageConstants.DEAL_NOT_FOUND_ERROR, ex.getMessage());

		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(DealNotCreatedException.class)
	public final ResponseEntity handleRequestConflictException(DealNotCreatedException ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(),
				ExceptionMessageConstants.DEAL_NOT_CREATED_ERROR, ex.getMessage());

		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(AllocationFoundException.class)
	public final ResponseEntity handleRequestConflictException(AllocationFoundException ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(),
				ExceptionMessageConstants.DEAL_NOT_CREATED_ERROR, ex.getMessage());

		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(ReportDownloadException.class)
	public final ResponseEntity handleRequestConflictException(ReportDownloadException ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(),
				ExceptionMessageConstants.REPORT_DOWNLOAD_EXCEPTION, ex.getMessage());

		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(BackFlowProcessException.class)
	public final ResponseEntity handleRequestConflictException(BackFlowProcessException ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(),
				ExceptionMessageConstants.BACKFLOWPROCESS_EXCEPTION, ex.getMessage());
		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(DealNotDeletedException.class)
	public final ResponseEntity handleRequestConflictException(DealNotDeletedException ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(),
				ExceptionMessageConstants.DEAL_NOT_CREATED_ERROR, ex.getMessage());

		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(DemandValidationException.class)
	public final ResponseEntity handleRequestConflictException(DemandValidationException ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(),
				ExceptionMessageConstants.DEMAND_NOT_VALIDATED, ex.getMessage());

		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
	}

	@Override
	protected ResponseEntity handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers,
			HttpStatus status, WebRequest request) {

		Map<String, Object> body = new LinkedHashMap<>();
		body.put("timestamp", new Date());
		body.put("status", status.value());
		List<String> errors = ex.getBindingResult().getFieldErrors().stream().map(x -> x.getDefaultMessage())
				.collect(Collectors.toList());

		body.put("errors", errors);

		return new ResponseEntity<>(body, status);
	}

	@ExceptionHandler(GroupedAllocationFoundException.class)
	public final ResponseEntity handleGroupedAllocationFoundException(GroupedAllocationFoundException ex,
			WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(),
				ExceptionMessageConstants.DEMAND_DETAILS_NOT_FOUND_ERROR, ex.getMessage());

		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(InvalidPageNumberException.class)
	public final ResponseEntity<Object> handleInvalidPageNoException(InvalidPageNumberException ex,
			WebRequest request) {

		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(),
				ExceptionMessageConstants.INVALID_PAGE_NUM, ex.getMessage());
		return new ResponseEntity<Object>(exceptionResponse, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(PersonSearchException.class)
	public final ResponseEntity<Object> handlePersonSearchException(PersonSearchException ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(),
				ExceptionMessageConstants.PERSON_SEARCH_FLOW_EXCEPTION, ex.getMessage());
		return new ResponseEntity<Object>(exceptionResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(DealsValidationException.class)
	public final ResponseEntity handleRequestConflictException(DealsValidationException ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(), ex.getMessage());
		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(UserNotAllowedException.class)
	public final ResponseEntity handleRequestConflictException(UserNotAllowedException ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(),
				ExceptionMessageConstants.USER_NOT_ALLOWED, ex.getMessage());

		return new ResponseEntity<>(exceptionResponse, HttpStatus.FORBIDDEN);
	}
	
	@ExceptionHandler(DemandNotUpdatedException.class)
	public final ResponseEntity handleRequestConflictException(DemandNotUpdatedException ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(),
				ExceptionMessageConstants.DEMAND_NOT_UPDATED_ERROR, ex.getMessage());

		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(DemandNotCreatedException.class)
	public final ResponseEntity handleRequestConflictException(DemandNotCreatedException ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(),
				ExceptionMessageConstants.DEMAND_NOT_CREATED_ERROR, ex.getMessage());

		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(CopyPidException.class)
	public final ResponseEntity handleRequestConflictException(CopyPidException ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(),ExceptionMessageConstants.COPY_PID_WITH_EXISTING_TEAM, ex.getMessage());
		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(ApproverWorkflowException.class)
	public final ResponseEntity handleRequestConflictException(ApproverWorkflowException ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(),
				ExceptionMessageConstants.APPROVER_NOT_VALIDATED, ex.getMessage());

		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(SelfNominationRequestValidationException.class)
	public final ResponseEntity<Object> handleNSelfNominationRequestFlowException(SelfNominationRequestValidationException ex,
																	  WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(),
				ExceptionMessageConstants.SELF_NOMINATION_EXCEPTION, ex.getMessage());
		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
	}


	@ExceptionHandler(InvalidArgumentException.class)
	public final ResponseEntity<Object> handleInvalidArgumentException(InvalidArgumentException ex,
																		   WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse(new Date(),ExceptionMessageConstants.INVALID_ARGUMENT_EXCEPTION,
			 ex.getMessage());
		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(GroApprovalHistoryNotFoundException.class)
	public ResponseEntity<ExceptionResponse> handleGroApprovalHistoryNotFoundException(GroApprovalHistoryNotFoundException ex) {
		ExceptionResponse errorResponse = new ExceptionResponse(new Date(),
				ExceptionMessageConstants.GRO_APPROVAL_HISTORY_EXCEPTION, ex.getMessage());
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(AllocationValidationException.class)
	public ResponseEntity<ExceptionResponse> handleAllocationValidationException(AllocationValidationException ex) {
		ExceptionResponse errorResponse = new ExceptionResponse(new Date(),
				ExceptionMessageConstants.ALLOCATION_VALIDATION_EXCEPTION, ex.getMessage());
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler({ENPLException.class})
	public ResponseEntity<ExceptionResponse> handleENPLException(ENPLException ex) {
		ExceptionResponse errorResponse = new ExceptionResponse(new Date(),
				ExceptionMessageConstants.AID_GENERATION_EXCEPTION, ex.getMessage());
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}
}
