package com.ps.nextgen.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.CONFLICT)
public class RequestConflictException extends RuntimeException {
	/**
	 * Exception class for input data.
	 */
	private static final long serialVersionUID = 1L;

	public RequestConflictException(String message) {

		super(message);
	}
}
