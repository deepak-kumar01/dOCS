package com.ps.nextgen.exceptions;

public class DemandNotUpdatedException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

	public DemandNotUpdatedException(String message) {
		
		super(message);
	}

}
