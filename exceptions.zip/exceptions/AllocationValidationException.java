package com.ps.nextgen.exceptions;

public class AllocationValidationException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public AllocationValidationException(String message) {
        super(message);

    }
}