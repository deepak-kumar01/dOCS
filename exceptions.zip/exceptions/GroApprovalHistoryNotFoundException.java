package com.ps.nextgen.exceptions;

public class GroApprovalHistoryNotFoundException extends RuntimeException {
    public GroApprovalHistoryNotFoundException(String message) {
        super(message);
    }
}
