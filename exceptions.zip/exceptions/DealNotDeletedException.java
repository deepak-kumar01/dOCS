package com.ps.nextgen.exceptions;

public class DealNotDeletedException  extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

	public DealNotDeletedException(String message) {
		super(message);

}

}
