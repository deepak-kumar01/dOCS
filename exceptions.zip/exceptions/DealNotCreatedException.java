package com.ps.nextgen.exceptions;

//@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
public class DealNotCreatedException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DealNotCreatedException(String message) {
		super(message);

	}

}

