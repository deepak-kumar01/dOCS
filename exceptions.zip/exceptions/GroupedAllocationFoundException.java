package com.ps.nextgen.exceptions;

public class GroupedAllocationFoundException  extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	public GroupedAllocationFoundException(String message) {
		super(message);

}
}
