package com.ps.nextgen.exceptions;


public class RefDataNotFoundException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public RefDataNotFoundException(String message) {
        super(message);
    }
}
