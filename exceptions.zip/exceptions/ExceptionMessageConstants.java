package com.ps.nextgen.exceptions;

public class ExceptionMessageConstants {

	public static final String MESSAGE_SPACE = " - ";
	public static final String INPUT_VALIDATIONS_FAILED_ERROR = "Request validation failed.Mandatory inputs are either null or empty.";
	public static final String RECORD_UNDER_MODIFICATION_ERROR = "Record under modification.Refresh and re-submit the request again.";
	public static final String DEAL_NOT_FOUND_ERROR = "Deal not found.";
	public static final String PERSON_SEARCH_FLOW_EXCEPTION = "Exception in Person Search Flow";
	public static final String DEAL_NOT_CREATED_ERROR = "Error while creating Deal.";
	public static final String DEMAND_DETAILS_NOT_FOUND_ERROR= "Demand details not found.";
	public static final String INVALID_PAGE_NUM= "Invalid page number";
	public static final String USER_NOT_ALLOWED = "User not allowed to access this API.";
	public static final String DEMAND_NOT_UPDATED_ERROR = "Demand not Updated.";
	public static final String DEMAND_NOT_CREATED_ERROR = "Demand not created.";
	public static final String DEMAND_NOT_COPIED_ERROR = "Demand not copied.";
	public static final String INTERNAL_MONGO_ERROR = "Server Error: Mongo Internal Exception ";
	public static final String DEMAND_NOT_VALIDATED = "Error while creating demand.";
	public static final String APPROVER_NOT_VALIDATED = "Not valid Input.";

	public static final String REPORT_DOWNLOAD_EXCEPTION = "Exception during Report Generation, ";

	public static final String DETAILS_NOT_SAVED_ERROR= "Details not saved.";

	public static final String BACKFLOWPROCESS_EXCEPTION = "Unexpected Error in BackFlow Process";

	public static final String SELF_NOMINATION_EXCEPTION= "Exception in the selfNominationRequest flow, Details are:";

	public static final String SELF_NOMINATION_WITHDRAWN_VALIDATION_EXCEPTION= "Exception in the selfNomination Withdrawn Request flow, Details are:";
	public static final String INVALID_ARGUMENT_EXCEPTION= "Invalid Argument Exception!";
	public static final String GRO_APPROVAL_HISTORY_EXCEPTION="Gro Approval History Exception";
	public static final String COPY_PID_WITH_EXISTING_TEAM = "CopyPid With Existing team encountered an exception";
    public static final String CONTRACT_EXTEND_ERROR= "Please extend the contract";
    public static final String ALLOCATION_VALIDATION_EXCEPTION= "Exception While Validating The Allocation Dates.";
	public static final String AID_GENERATION_EXCEPTION= "Exception While Generating Assignment ID.";
}
