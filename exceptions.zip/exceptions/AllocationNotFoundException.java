package com.ps.nextgen.exceptions;

public class AllocationNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public AllocationNotFoundException(String message) {
		super(message);
	}
}
